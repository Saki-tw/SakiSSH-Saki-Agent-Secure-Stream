# Evidence Pre-Release Codename Mapping

> **生成時間**：2026-05-31 16:23 (UTC+8)
> **用途**：Pre-review 版證據庫的代號替換對照表。此檔案 **不上傳 GitHub**。

---

## 替換規則

| 原始名稱 | 替換為 | 層級 |
|----------|--------|------|
| Antigravity | Cortex | 產品（Agent 引擎） |
| Windsurf | Cortex | 產品（Agent 引擎） |
| Codeium | Cortex-Vendor | 廠商 |
| Gemini CLI | Clearcut | 產品（CLI 工具） |
| Gemini | Confucius | 模型/產品 |
| Claude Code | Statsig | 產品（CLI 工具） |
| Claude Opus 4.6 | Tengu 4.6 | 模型 |
| Claude | Tengu | 模型 |
| Google DeepMind | Confucius-Vendor | 廠商 |
| Google Cloud | Confucius-Cloud | 雲端 |
| Anthropic | Tengu-Vendor | 廠商 |
| Saki Studio | [OPERATOR] | 機構 |
| SakiStudio | [OPERATOR] | 機構 |
| Saki-tw | [OPERATOR] | 機構 |
| sakistudio.com.tw | [OPERATOR-DOMAIN] | 網域 |
| saki@ | [REDACTED]@ | 信箱 |
| SakiMed | [OPERATOR-MED] | 子專案 |

## 未替換（刻意保留）

| 項目 | 原因 |
|------|------|
| 版本號（v1.21.6, v1.23.2 等） | Reproducibility 命脈 |
| proto field 編號 | 技術必要 |
| $HOME / $PROJECT_ROOT | 已在原始脫敏時替換 |
| [REDACTED_TOKEN] 等 | 已在原始脫敏時替換 |

## 檔案清單

| 原始檔案 | Pre-release 檔案 | 替換數 |
|----------|-----------------|:------:|
| A1_manifesto.md | ✅ 同名 | ~11 |
| A2_post_defeat_reflection.md | ✅ 同名 | ~6 |
| A3_infrastructure_takeover_plan.md | ✅ 同名 | ~14 |
| A4_medical_system_execution.md | ✅ 同名 | ~7 |
| A5_302_session_analysis.md | ✅ 同名 | ~39 |
| A6_cli_logs_research.md | ✅ 同名 | ~15 |
| A7_history_analysis.md | ✅ 同名 | ~27 |
| B1_forensic_audit.md | ✅ 同名 | ~47 |
| C1_session_log.log | ✅ 同名 | ~344 |
| C2_incident_window.log | ✅ 同名 | ~487 |
| C3_grpc_capture_summary.md | ✅ 同名 | — |
| D1_corroborating_incidents.md | ✅ 同名 | ~10 |
| E1_corpus_statistics.md | ✅ 同名 | ~5 |
| README.md | ✅ 同名 | ~4 |
